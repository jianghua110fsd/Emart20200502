import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item-insert',
  templateUrl: './item-insert.component.html',
  styleUrls: ['./item-insert.component.css']
})
export class ItemInsertComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

goBack(): void {
  history.go(-1);
}
}
