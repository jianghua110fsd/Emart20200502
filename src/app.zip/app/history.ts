export const history = [
  {
    orderNo: 'P11001',
    orderDate: '2019-03-15',
    productName: 'Phone XL',
    productNO: 'E00111',
    category: 'Electronics',
    subcategory: 'Phone',
    unit: 'Tai',
    price: 3888,
    quantity: 1
  },
  {
    orderNo: 'P11001',
    orderDate: '2016-01-15',
    productName: '4MATIC',
    productNO: 'E00002',
    category: 'Automobile',
    subcategory: 'Mercedes-Benz',
    unit: 'Tai',
    price: 6888,
    quantity: 2
  },
  {
    orderNo: 'P11001',
    orderDate: '2013-11-03',
    productName: 'Tissue',
    productNO: 'D00003',
    category: 'Daily item',
    subcategory: 'Family',
    unit: 'Kuai',
    price: 1888,
    quantity: 1
  },
];