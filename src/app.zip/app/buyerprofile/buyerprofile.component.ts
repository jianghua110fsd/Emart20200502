import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyerprofile',
  templateUrl: './buyerprofile.component.html',
  styleUrls: ['./buyerprofile.component.css']
})
export class BuyerprofileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
