export const searchlist = [
  {
    productName: 'Phone XL',
    productNO: 'P00001',
    category: 'Electronics',
    subcategory: 'Phone',
    unit: 'Tai',
    price: 3888,
    stockNumber: 88,
    remarks:'Apple'
  },
  {
    productName: '4MATIC',
    productNO: 'A00002',
    category: 'Automobile',
    subcategory: 'Mercedes-Benz',
    unit: 'Tai',
    price: 588888,
    stockNumber: 99,
    remarks:'DRP 37435'
  },
  {
    productName: 'Casio',
    productNO: 'W00003',
    category: 'Watch',
    subcategory: 'Quartz watch',
    unit: 'Kuai',
    price: 18888,
    stockNumber: 999,
    remarks:'Swatch Group'
  },
];